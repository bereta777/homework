num = int(input("შეიყვანეთ რიცხვი: "))
pasuxi =1
for i in range(1 , num + 1 ):
    pasuxi = pasuxi * i
print("ფაქტორიალია:", pasuxi)

ricxvi= int( input("შეიყვანეთ რიცხვი"))
for i in range(1,10):
    print(ricxvi,"*", i, "=", ricxvi * i)


print("მხოლოდ 5, 10 ან 20 კუპიურებს იღებს")
tanxa=0
while tanxa< 50:
    lari = int(input("შეიყვანეთ კუპიოურა:"))
    if lari==5 or lari==10 or lari==20:
        tanxa= tanxa + lari
        print("შეტანილი თანხა:", tanxa, "ლარი" )
    else:
        print("მხოლოდ 5, 10 და 20 ლარიანები მიიღება")
if tanxa==50:
    print("გადახდილია")
else:
    xurda= tanxa - 50
    print("გადახდილია, თქვენი ხურდაა:", xurda, "ლარი")
